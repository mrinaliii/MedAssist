# backend/app/api/routes/__init__.py

from fastapi import APIRouter

router = APIRouter()

from . import chat, health

router.include_router(chat.router, prefix="/chat", tags=["chat"])
router.include_router(health.router, prefix="/health", tags=["health"])