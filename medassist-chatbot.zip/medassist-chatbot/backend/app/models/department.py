from pydantic import BaseModel
from typing import List, Optional

class Department(BaseModel):
    id: int
    name: str
    description: Optional[str] = None

class DepartmentList(BaseModel):
    departments: List[Department]