from pydantic import BaseModel
from typing import List, Optional

class ChatInput(BaseModel):
    user_id: str
    message: str

class ChatResponse(BaseModel):
    response: str
    suggestions: Optional[List[str]] = None
    confidence: float

class ChatHistory(BaseModel):
    user_id: str
    messages: List[ChatInput]