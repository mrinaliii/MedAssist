from pydantic import BaseSettings

class Settings(BaseSettings):
    llm_model: str = "Llama 3"
    llm_api_key: str
    llm_api_url: str = "https://api.llama3.example.com"
    debug: bool = False

    class Config:
        env_file = ".env"

settings = Settings()