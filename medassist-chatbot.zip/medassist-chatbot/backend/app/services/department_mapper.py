class DepartmentMapper:
    def __init__(self):
        self.department_mapping = {
            "fever": "General Medicine",
            "cough": "Pulmonology",
            "headache": "Neurology",
            "stomach pain": "Gastroenterology",
            "skin rash": "Dermatology",
            "joint pain": "Rheumatology",
            "chest pain": "Cardiology",
            "mental health": "Psychiatry",
        }

    def map_symptom_to_department(self, symptom):
        return self.department_mapping.get(symptom.lower(), "General Medicine")