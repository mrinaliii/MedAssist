# MedAssist Chatbot

MedAssist is an LLM-powered chatbot designed to assist users with medical inquiries by analyzing symptoms and providing recommendations. The application leverages FastAPI for the backend, Llama 3 for language model inference, and a responsive frontend built with HTML and Tailwind CSS. Additionally, it features voice recognition capabilities to convert spoken English input into text.

## Project Structure

```
medassist-chatbot
├── backend
│   ├── app
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── api
│   │   │   ├── __init__.py
│   │   │   └── routes
│   │   │       ├── __init__.py
│   │   │       ├── chat.py
│   │   │       └── health.py
│   │   ├── core
│   │   │   ├── __init__.py
│   │   │   ├── config.py
│   │   │   └── llm.py
│   │   ├── models
│   │   │   ├── __init__.py
│   │   │   ├── chat.py
│   │   │   └── department.py
│   │   └── services
│   │       ├── __init__.py
│   │       ├── symptom_analyzer.py
│   │       └── department_mapper.py
│   ├── requirements.txt
│   └── pyproject.toml
├── frontend
│   ├── index.html
│   ├── css
│   │   └── styles.css
│   ├── js
│   │   ├── main.js
│   │   ├── chat.js
│   │   └── voice-recognition.js
│   └── assets
│       └── favicon.svg
├── tests
│   ├── __init__.py
│   ├── test_api.py
│   └── test_services.py
├── docs
│   └── api.md
├── .env.example
├── .gitignore
├── docker-compose.yml
├── Dockerfile
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/medassist-chatbot.git
   cd medassist-chatbot
   ```

2. Set up the backend:
   - Navigate to the `backend` directory.
   - Install the required dependencies:
     ```
     pip install -r requirements.txt
     ```

3. Set up the frontend:
   - Navigate to the `frontend` directory.
   - Open `index.html` in your preferred web browser.

## Usage

- Start the FastAPI backend:
  ```
  uvicorn app.main:app --reload
  ```

- Access the API documentation at `http://localhost:8000/docs`.

- Use the frontend interface to interact with the chatbot. You can type your symptoms or use the voice recognition feature to speak your input.

## Features

- **LLM Integration**: Utilizes Llama 3 for generating responses based on user input.
- **Voice Recognition**: Converts spoken English input to text for seamless interaction.
- **Health Check Endpoint**: Verify that the API is running smoothly.
- **Symptom Analysis**: Provides recommendations based on user-reported symptoms.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.