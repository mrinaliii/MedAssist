const startButton = document.getElementById('start-button');
const stopButton = document.getElementById('stop-button');
const outputArea = document.getElementById('output-area');

let recognition;

if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = function() {
        outputArea.innerHTML = 'Voice recognition activated. Try speaking into the microphone.';
    };

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        outputArea.innerHTML = 'You said: ' + transcript;
        // Here you can add code to send the transcript to the chatbot API
    };

    recognition.onerror = function(event) {
        outputArea.innerHTML = 'Error occurred in recognition: ' + event.error;
    };

    recognition.onend = function() {
        outputArea.innerHTML += '<br>Voice recognition deactivated.';
    };

    startButton.addEventListener('click', function() {
        recognition.start();
    });

    stopButton.addEventListener('click', function() {
        recognition.stop();
    });
} else {
    outputArea.innerHTML = 'Your browser does not support speech recognition.';
}