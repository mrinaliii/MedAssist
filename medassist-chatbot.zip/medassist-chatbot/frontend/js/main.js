// This file contains the main JavaScript logic for the frontend, handling user interactions and API calls.

document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatOutput = document.getElementById('chat-output');

    chatForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const userInput = chatInput.value;
        chatInput.value = '';

        if (userInput) {
            appendMessage('You: ' + userInput);
            const response = await sendMessageToAPI(userInput);
            appendMessage('Bot: ' + response);
        }
    });

    function appendMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.textContent = message;
        chatOutput.appendChild(messageElement);
    }

    async function sendMessageToAPI(message) {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message }),
        });

        if (!response.ok) {
            console.error('Error:', response.statusText);
            return 'Error: Unable to get response from the server.';
        }

        const data = await response.json();
        return data.reply; // Assuming the API returns a JSON object with a 'reply' field
    }
});