// This file contains JavaScript functions specifically for managing chat interactions with the backend.

const chatInput = document.getElementById('chat-input');
const chatOutput = document.getElementById('chat-output');
const sendButton = document.getElementById('send-button');

sendButton.addEventListener('click', async () => {
    const userMessage = chatInput.value;
    if (userMessage.trim() === '') return;

    appendMessage('You: ' + userMessage);
    chatInput.value = '';

    const response = await sendMessageToChatbot(userMessage);
    appendMessage('Bot: ' + response);
});

async function sendMessageToChatbot(message) {
    const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message }),
    });

    if (!response.ok) {
        console.error('Error:', response.statusText);
        return 'Sorry, there was an error processing your request.';
    }

    const data = await response.json();
    return data.reply;
}

function appendMessage(message) {
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    chatOutput.appendChild(messageElement);
    chatOutput.scrollTop = chatOutput.scrollHeight; // Scroll to the bottom
}