from fastapi import HTTPException
from app.services.symptom_analyzer import SymptomAnalyzer
from app.services.department_mapper import DepartmentMapper

def test_symptom_analyzer():
    analyzer = SymptomAnalyzer()
    result = analyzer.analyze("I have a headache and fever")
    assert result is not None
    assert "headache" in result["symptoms"]
    assert "fever" in result["symptoms"]

def test_department_mapper():
    mapper = DepartmentMapper()
    department = mapper.map_symptoms_to_department(["headache", "fever"])
    assert department == "Neurology"  # Assuming headache maps to Neurology
    department = mapper.map_symptoms_to_department(["cough", "sore throat"])
    assert department == "ENT"  # Assuming cough maps to ENT