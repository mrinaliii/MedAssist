# MedAssist API Documentation

## Overview
MedAssist is an LLM-powered chatbot designed to assist users with medical inquiries and symptom analysis. This documentation outlines the API endpoints available for interaction with the MedAssist backend.

## Base URL
The base URL for the API is:
```
http://localhost:8000/api
```

## Endpoints

### Health Check
- **Endpoint:** `/health`
- **Method:** `GET`
- **Description:** Checks the health status of the API.
- **Response:**
  - **200 OK:** Returns a JSON object indicating the API is running.
    ```json
    {
      "status": "healthy"
    }
    ```

### Chat Interaction
- **Endpoint:** `/chat`
- **Method:** `POST`
- **Description:** Processes user input for chat interactions and returns responses from the LLM.
- **Request Body:**
  - **Content-Type:** `application/json`
  - **Schema:**
    ```json
    {
      "user_input": "string"
    }
    ```
- **Response:**
  - **200 OK:** Returns a JSON object with the LLM's response.
    ```json
    {
      "response": "string"
    }
    ```
  - **400 Bad Request:** If the input is invalid.
    ```json
    {
      "detail": "Invalid input"
    }
    ```

## Usage
To interact with the API, send requests to the specified endpoints using a tool like Postman or through your frontend application. Ensure that the backend server is running before making requests.

## Notes
- Ensure that all requests to the `/chat` endpoint include valid JSON formatted input.
- The health check endpoint can be used to verify that the API is operational before making other requests.